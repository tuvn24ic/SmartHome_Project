package com.example.doant2

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.google.firebase.database.*
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

// --- MÀU PHONG THỦY MỆNH THỔ ---
val ThoOrangePrimary = Color(0xFFE65100) // Cam đất đậm (Bản mệnh / Hỏa)
val ThoBrownPrimary = Color(0xFF6D4C41) // Nâu đất mộc mạc (Bản mệnh)
val ThoBeige = Color(0xFFFFE0B2) // Vàng cát / Be nhạt (Bản mệnh)
val HoaRed = Color(0xFFD32F2F) // Đỏ tươi (Tương sinh - Hỏa sinh Thổ)
val MyOrange = Color(0xFFF57C00) // Cam sáng

data class UserPermission(
    val id: String = "",
    val name: String = "",
    val canLiving: Boolean = true,
    val canKitchen: Boolean = true,
    val canBedroom: Boolean = true,
    val canBalcony: Boolean = true,
    val canSecurity: Boolean = false
)

class MainActivity : ComponentActivity() {
    private val requestPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        createNotificationChannel()

        setContent {
            val isDark = isSystemInDarkTheme()
            // ÁP DỤNG MÀU NỀN & CHỮ MỆNH THỔ
            val bgColor = if (isDark) Color(0xFF2D1812) else Color(0xFFFFF8E1) // Nâu đen tối / Vàng kem nhạt
            val textColor = if (isDark) Color(0xFFFFF8E1) else Color(0xFF3E2723) // Vàng nhạt / Nâu cafe đậm

            val cardColor = if (isDark) Color(0xFF4E342E) else Color.White // Nâu cafe sáng / Trắng tinh khiết

            MaterialTheme(colorScheme = if (isDark) darkColorScheme() else lightColorScheme()) {
                val navController = rememberNavController()
                val db = Firebase.database.reference.child("SmartHome")

                var userRole by remember { mutableStateOf("guest") }
                var currentUserId by remember { mutableStateOf("") }
                var permissions by remember { mutableStateOf(UserPermission()) }

                val tempHistory = remember { mutableStateListOf<Float>(28f, 29f, 28.5f, 30f, 31f, 30.5f) }
                var temp by remember { mutableDoubleStateOf(0.0) }

                var humi by remember { mutableDoubleStateOf(0.0) }
                var gas by remember { mutableIntStateOf(0) }
                var coLua by remember { mutableIntStateOf(0) }
                var isRain by remember { mutableStateOf(false) }

                var phoiDo by remember { mutableIntStateOf(0) }
                var autoPhoi by remember { mutableIntStateOf(0) }
                var phoiStartTime by remember { mutableLongStateOf(0L) }

                var hasPerson by remember { mutableStateOf(false) }
                var lastRfid by remember { mutableStateOf("") }
                var canhBaoPIR by remember { mutableStateOf(false) }
                var coiBaoDong by remember { mutableIntStateOf(0) }
                var servoDoorState by remember { mutableIntStateOf(0) }

                var denKhach by remember { mutableIntStateOf(0) }
                var dieuHoa by remember { mutableIntStateOf(0) }
                var denBep by remember { mutableIntStateOf(0) }

                var quatBep by remember { mutableIntStateOf(0) }
                var denNgu by remember { mutableIntStateOf(0) }
                var quatNgu by remember { mutableIntStateOf(0) }
                var timerDenNgu by remember { mutableStateOf("Chưa đặt") }
                var timerQuatNgu by remember { mutableStateOf("Chưa đặt") }
                val historyList = remember { mutableStateListOf<Pair<String, String>>() }

                LaunchedEffect(currentUserId) {
                    if (userRole == "admin") {
                        permissions = UserPermission(id="admin", name="CHỦ NHÀ", canSecurity = true)
                    } else if (currentUserId.isNotEmpty()) {
                        db.child("Users").child(currentUserId).addValueEventListener(object : ValueEventListener {
                            override fun onDataChange(s: DataSnapshot) {

                                permissions = s.getValue(UserPermission::class.java) ?: UserPermission(name="KHÁCH")
                            }
                            override fun onCancelled(e: DatabaseError) {}

                        })
                    }
                }

                LaunchedEffect(Unit) {
                    db.addValueEventListener(object : ValueEventListener {

                        override fun onDataChange(s: DataSnapshot) {
                            val nTemp = s.child("PhongKhach/NhietDo").value.toString().toDoubleOrNull() ?: 0.0
                            if (temp != nTemp && nTemp > 0) {

                                temp = nTemp
                                if(tempHistory.size >= 10) tempHistory.removeAt(0)
                                tempHistory.add(nTemp.toFloat())

                            }
                            humi = s.child("PhongKhach/DoAm").value.toString().toDoubleOrNull() ?: 0.0
                            gas = s.child("NhaBep/GasValue").value.toString().toIntOrNull() ?: 0
                            coLua = s.child("NhaBep/CoLua").value.toString().toIntOrNull() ?: 0
                            isRain = (s.child("BanCong/CamBienMua").value.toString().toIntOrNull() ?: 0) == 1
                            phoiDo = s.child("BanCong/GiaPhoi").value.toString().toIntOrNull() ?: 0
                            autoPhoi = s.child("BanCong/AutoMode").value.toString().toIntOrNull() ?: 0
                            phoiStartTime = s.child("BanCong/StartTime").value.toString().toLongOrNull() ?: 0L

                            hasPerson = (s.child("NhaVeSinh/CoNguoi").value.toString().toIntOrNull() ?: 0) == 1
                            canhBaoPIR = (s.child("CuaChinh/CanhBao").value.toString().toIntOrNull() ?: 0) == 1
                            coiBaoDong = s.child("CuaChinh/Coi").value.toString().toIntOrNull() ?: 0
                            servoDoorState = s.child("CuaChinh/Servo").value.toString().toIntOrNull() ?: 0

                            denKhach = s.child("PhongKhach/Den").value.toString().toIntOrNull() ?: 0

                            dieuHoa = s.child("PhongKhach/DieuHoa").value.toString().toIntOrNull() ?: 0
                            denBep = s.child("NhaBep/Den").value.toString().toIntOrNull() ?: 0
                            quatBep = s.child("NhaBep/QuatHut").value.toString().toIntOrNull() ?: 0

                            denNgu = s.child("PhongNgu/Den").value.toString().toIntOrNull() ?: 0
                            quatNgu = s.child("PhongNgu/Quat").value.toString().toIntOrNull() ?: 0
                            timerDenNgu = s.child("PhongNgu/TimerDen").value?.toString() ?: "Chưa đặt"

                            timerQuatNgu = s.child("PhongNgu/TimerQuat").value?.toString() ?: "Chưa đặt"
                            lastRfid = s.child("CuaChinh/TheCuoi").value?.toString() ?: ""
                        }
                        override fun onCancelled(e: DatabaseError) {}
                    })

                    db.child("LichSu").limitToLast(10).addValueEventListener(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {

                            historyList.clear()
                            snapshot.children.reversed().forEach { historyList.add(it.child("name").value.toString() to it.child("time").value.toString()) }
                        }
                        override fun onCancelled(e: DatabaseError) {}

                    })
                }

                Surface(color = bgColor, modifier = Modifier.fillMaxSize()) {
                    NavHost(navController = navController, startDestination = "login") {
                        composable("login") {

                            LoginScreen(textColor) { role, id ->
                                userRole = role
                                currentUserId = id

                                navController.navigate("home") { popUpTo("login") { inclusive = true } }
                            }
                        }

                        composable("home") {
                            HomeScreen(navController, db, userRole, permissions, temp, gas, isRain, hasPerson, canhBaoPIR, textColor, cardColor, tempHistory)
                        }

                        composable("living") { LivingScreen(navController, db, temp, humi, denKhach, dieuHoa, textColor, cardColor) }
                        composable("kitchen") { KitchenScreen(navController, db, gas, coLua, denBep, quatBep, textColor, cardColor) }
                        composable("bedroom") { BedroomScreen(navController, db, denNgu, quatNgu, timerDenNgu, timerQuatNgu, textColor, cardColor) }

                        composable("balcony") { BalconyScreen(navController, db, isRain, phoiDo, autoPhoi, phoiStartTime, textColor, cardColor) }
                        composable("security") { SecurityScreen(navController, db, canhBaoPIR, coiBaoDong, servoDoorState, lastRfid, userRole, permissions, historyList, textColor, cardColor) }
                        composable("admin_manage") { AdminManageScreen(navController, db, textColor, cardColor) }

                    }
                }
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("SMART_HOME", "Báo động Nhà Thông Minh", NotificationManager.IMPORTANCE_HIGH)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        }
    }
}

// ================= GIAO DIỆN ĐĂNG NHẬP (Tông Vàng Cát & Cam Đất) =================
@Composable
fun LoginScreen(textColor: Color, onLogin: (String, String) -> Unit) {
    var inputId by remember { mutableStateOf("") }
    Column(modifier = Modifier.fillMaxSize().padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.Home, null, modifier = Modifier.size(100.dp), tint = ThoOrangePrimary)
        Text("SMART HOME", fontSize = 32.sp, fontWeight = FontWeight.Black, color = textColor)
        Text("Hệ thống quản lý thông minh", fontSize = 14.sp, color = ThoBrownPrimary, modifier = Modifier.padding(bottom = 40.dp))

        OutlinedTextField(
            value = inputId,
            onValueChange = { inputId = it },
            label = { Text("Nhập ID Đăng nhập") },
            singleLine = true,
            shape = RoundedCornerShape(15.dp),

            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ThoOrangePrimary,
                focusedLabelColor = ThoOrangePrimary
            )
        )

        Spacer(modifier = Modifier.height(25.dp))

        Button(

            onClick = {
                if (inputId.isNotBlank()) {
                    if(inputId.lowercase() == "admin") onLogin("admin", "admin")
                    else onLogin("guest", inputId)
                }

            },
            modifier = Modifier.fillMaxWidth().height(55.dp),
            colors = ButtonDefaults.buttonColors(containerColor = ThoOrangePrimary),
            shape = RoundedCornerShape(15.dp)
        ) {
            Text("ĐĂNG NHẬP", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// ================= GIAO DIỆN TRANG CHỦ =================
@Composable
fun HomeScreen(navController: NavHostController, db: DatabaseReference, role: String, per: UserPermission,
               temp: Double, gas: Int, rain: Boolean, person: Boolean, warning: Boolean, textColor: Color, cardColor: Color, tempHistory: List<Float>) {
    LazyColumn(modifier = Modifier.padding(horizontal = 20.dp), contentPadding = PaddingValues(vertical = 20.dp)) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("TÀI KHOẢN:", fontSize = 12.sp, color = ThoBrownPrimary)
                    Text(if(role=="admin") "ADMIN" else "KHÁCH", fontWeight = FontWeight.Black, fontSize = 24.sp, color = textColor)
                }
                IconButton(onClick = { navController.navigate("login") { popUpTo(0) } }) {
                    Icon(Icons.Default.Logout, null, tint = HoaRed, modifier = Modifier.size(28.dp))
                }
            }
            Spacer(modifier = Modifier.height(15.dp))

            if (role == "admin") {
                Button(onClick = { navController.navigate("admin_manage") }, modifier = Modifier.fillMaxWidth().height(50.dp), colors = ButtonDefaults.buttonColors(containerColor = ThoBrownPrimary), shape = RoundedCornerShape(12.dp)) {

                    Icon(Icons.Default.ManageAccounts, null)
                    Text(" QUẢN LÝ TÀI KHOẢN KHÁCH", fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(15.dp))
            }

            // BIỂU ĐỒ NHIỆT ĐỘ CÓ ĐỈNH / ĐÁY MÀU PHONG THỦY THỔ
            Card(modifier = Modifier.fillMaxWidth().height(160.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF4E342E)), shape = RoundedCornerShape(20.dp)) { // Nền nâu cafe
                Column(modifier = Modifier.padding(15.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {

                        Text("Biểu đồ Nhiệt độ (°C)", color = Color.White, fontWeight = FontWeight.Bold)
                        if (tempHistory.isNotEmpty()) {
                            Row {

                                Text("Đỉnh: ${tempHistory.maxOrNull()}° ", color = Color(0xFFFF5252), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("Đáy: ${tempHistory.minOrNull()}°", color = ThoBeige, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    LineChartNative(data = tempHistory)
                }

            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        item {
            LazyVerticalGrid(columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(15.dp), verticalArrangement = Arrangement.spacedBy(15.dp), modifier = Modifier.height(440.dp)) {
                // Phối màu Icon dựa theo Hỏa & Thổ
                item { RoomCard("Phòng Khách", if(per.canLiving) "$temp°C" else "Đã khóa", Icons.Default.Weekend, ThoOrangePrimary, cardColor, textColor, per.canLiving) { navController.navigate("living") } }
                item { RoomCard("Nhà Bếp", if(per.canKitchen) "Gas: $gas" else "Đã khóa", Icons.Default.Kitchen, HoaRed, cardColor, textColor, per.canKitchen) { navController.navigate("kitchen") } }
                item { RoomCard("Ban Công", if(per.canBalcony) (if(rain) "Mưa" else "Nắng") else "Đã khóa", Icons.Default.WbSunny, MyOrange, cardColor, textColor, per.canBalcony) { navController.navigate("balcony") } }

                item { RoomCard("Cửa Chính", if(per.canSecurity) "Đóng/Mở từ xa" else "Đã khóa", Icons.Default.DoorFront, ThoBrownPrimary, cardColor, textColor, per.canSecurity) { navController.navigate("security") } }
                item { RoomCard("Phòng Ngủ", if(per.canBedroom) "Đèn/Quạt" else "Đã khóa", Icons.Default.Bed, Color(0xFF8D6E63), cardColor, textColor, per.canBedroom) { navController.navigate("bedroom") } }
                item {
                    Card(modifier = Modifier.height(130.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = if(person) ThoBeige else cardColor)) {
                        Column(modifier = Modifier.padding(15.dp).fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                            Icon(Icons.Default.Wc, null, tint = if(person) ThoOrangePrimary else Color.Gray, modifier = Modifier.size(35.dp))

                            Text("Vệ Sinh\n${if(person) "CÓ NGƯỜI" else "TRỐNG"}", color = if(person) ThoBrownPrimary else textColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }

        }

        if (role == "admin") {
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Text("KỊCH BẢN TỰ ĐỘNG (CHỈ ADMIN)", fontWeight = FontWeight.Bold, color = ThoBrownPrimary, fontSize = 14.sp, modifier = Modifier.padding(bottom = 10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(15.dp), modifier = Modifier.fillMaxWidth()) {
                    ScenarioButton("Ở nhà", Icons.Default.Home, ThoOrangePrimary, Modifier.weight(1f)) {
                        db.child("PhongKhach/Den").setValue(1)
                        db.child("CuaChinh/CanhBao").setValue(0); db.child("CuaChinh/Coi").setValue(0)
                    }
                    ScenarioButton("Đi vắng", Icons.Default.DirectionsWalk, ThoBrownPrimary, Modifier.weight(1f)) {
                        db.child("PhongKhach/Den").setValue(0)
                        db.child("NhaBep/Den").setValue(0); db.child("PhongNgu/Den").setValue(0)
                        db.child("PhongKhach/DieuHoa").setValue(0)
                        db.child("PhongNgu/Quat").setValue(0)
                        db.child("CuaChinh/CanhBao").setValue(1)
                    }
                }
            }
        }
    }
}

// ================= MÀN HÌNH QUẢN LÝ TÀI KHOẢN KHÁCH =================
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AdminManageScreen(navController: NavHostController, db: DatabaseReference, textColor: Color, cardColor: Color) {
    var guestList by remember { mutableStateOf(listOf<UserPermission>()) }
    var showAddDialog by remember { mutableStateOf(false) }

    var newId by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        db.child("Users").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                val list = mutableListOf<UserPermission>()
                s.children.forEach { it.getValue(UserPermission::class.java)?.let { u -> list.add(u) } }

                guestList = list
            }
            override fun onCancelled(e: DatabaseError) {}
        })
    }

    Column(modifier = Modifier.padding(20.dp)) {
        Header(navController, "QUẢN LÝ TÀI KHOẢN KHÁCH", textColor)
        Button(onClick = { showAddDialog = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = ThoOrangePrimary)) {
            Icon(Icons.Default.PersonAdd, null)

            Text(" TẠO ID KHÁCH MỚI")
        }
        Spacer(modifier = Modifier.height(20.dp))
        LazyColumn {
            items(guestList) { guest ->
                WhiteCard(cardColor, modifier = Modifier.padding(bottom = 12.dp)) {
                    Column(modifier = Modifier.padding(15.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AccountCircle, null, tint = ThoBrownPrimary, modifier = Modifier.size(40.dp))
                            Column(modifier = Modifier.weight(1f).padding(start = 10.dp)) {

                                Text("Khách ID: ${guest.id}", fontWeight = FontWeight.Bold, color = textColor)
                            }
                            IconButton(onClick = { db.child("Users").child(guest.id).removeValue() }) {

                                Icon(Icons.Default.Delete, null, tint = HoaRed)
                            }
                        }

                        Text("Phân quyền truy cập phòng:", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top=10.dp))
                        FlowRow(modifier = Modifier.fillMaxWidth()) {
                            PermissionToggle("Phòng Khách", guest.canLiving) { db.child("Users").child(guest.id).child("canLiving").setValue(it) }

                            PermissionToggle("Nhà Bếp", guest.canKitchen) { db.child("Users").child(guest.id).child("canKitchen").setValue(it) }
                            PermissionToggle("Phòng Ngủ", guest.canBedroom) { db.child("Users").child(guest.id).child("canBedroom").setValue(it) }
                            PermissionToggle("Ban Công", guest.canBalcony) { db.child("Users").child(guest.id).child("canBalcony").setValue(it) }

                            PermissionToggle("Cửa An Ninh", guest.canSecurity) { db.child("Users").child(guest.id).child("canSecurity").setValue(it) }
                        }
                    }
                }
            }
        }

    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Tạo ID Khách", color = ThoOrangePrimary, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(

                    value = newId, onValueChange = { newId = it },
                    label = { Text("Nhập ID (VD: khach123)") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ThoOrangePrimary, focusedLabelColor = ThoOrangePrimary)

                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if(newId.isNotEmpty()){

                            db.child("Users").child(newId).setValue(UserPermission(id=newId, name="KHÁCH"))
                            newId = ""
                            showAddDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ThoOrangePrimary)
                ) { Text("XÁC NHẬN") }

            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionToggle(label: String, isEnabled: Boolean, onToggle: (Boolean) -> Unit) {
    FilterChip(
        selected = isEnabled,
        onClick = { onToggle(!isEnabled) },
        label = { Text(label, fontSize = 11.sp) },
        modifier = Modifier.padding(end = 4.dp),
        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ThoBeige, selectedLabelColor = ThoOrangePrimary),
        leadingIcon = if (isEnabled) { { Icon(Icons.Default.Check, null, modifier = Modifier.size(14.dp), tint = ThoOrangePrimary) } } else null
    )
}

// ================= CỬA CHÍNH (Đã sửa thành nút bấm 2 chiều Đóng/Mở & hỗ trợ quét thẻ từ) =================
@Composable
fun SecurityScreen(navController: NavHostController, db: DatabaseReference, warning: Boolean, coi: Int, servoState: Int, rfid: String, userRole: String, permissions: UserPermission, history: List<Pair<String, String>>, textColor: Color, cardColor: Color) {
    val canOpenDoor = userRole == "admin" || permissions.canSecurity
    val isDoorOpen = (servoState == 90)

    LazyColumn(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        item {
            Header(navController, "CỬA CHÍNH TỪ XA", textColor)
            if(warning) Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))) { Text("⚠️ ĐÃ BẬT CẢNH BÁO AN NINH!", color = HoaRed, modifier = Modifier.padding(15.dp), fontWeight = FontWeight.Bold) }
            Spacer(modifier = Modifier.height(20.dp))

            if (!canOpenDoor) {
                Text("⚠️ Tài khoản của bạn không được cấp phép mở cửa!", color = HoaRed, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(20.dp))
            }

            // NÚT BẤM 2 CHIỀU ĐỒNG BỘ: NHẤN ĐỂ ĐỔI TRẠNG THÁI ĐÓNG / MỞ
            Button(
                onClick = {
                    if (canOpenDoor) {
                        val nextState = if (isDoorOpen) 0 else 90
                        db.child("CuaChinh/Servo").setValue(nextState)
                    }
                },
                enabled = canOpenDoor,
                modifier = Modifier.size(160.dp),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if(isDoorOpen) ThoOrangePrimary else ThoBrownPrimary,
                    disabledContainerColor = Color.LightGray
                )
            ) {
                Text(
                    if(!canOpenDoor) "BỊ KHÓA" else if(isDoorOpen) "CỬA ĐANG MỞ\n(BẤM ĐỂ ĐÓNG)" else "CỬA ĐANG ĐÓNG\n(BẤM ĐỂ MỞ)",
                    textAlign = TextAlign.Center,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
            Text("Thẻ vật lý quẹt cuối: $rfid", color = Color.Gray, fontWeight = FontWeight.Bold)

            if (canOpenDoor) {
                ControlRow(Icons.Default.VolumeUp, "Còi báo động", coi == 1, textColor, cardColor) { db.child("CuaChinh/Coi").setValue(if(it) 1 else 0) }
            }

            Spacer(modifier = Modifier.height(30.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) { Text("LỊCH SỬ RA VÀO", fontWeight = FontWeight.Bold, color = Color.Gray, fontSize = 14.sp) }
            Spacer(modifier = Modifier.height(10.dp))
        }
        items(history) { item ->
            WhiteCard(cardColor, modifier = Modifier.padding(bottom = 8.dp)) {
                Row(modifier = Modifier.padding(15.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(item.first, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = textColor)

                    Text(item.second, color = Color.Gray, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun LivingScreen(navController: NavHostController, db: DatabaseReference, temp: Double, humi: Double, den: Int, ac: Int, textColor: Color, cardColor: Color) {
    Column(modifier = Modifier.padding(20.dp)) {
        Header(navController, "PHÒNG KHÁCH", textColor)

        GaugeLight(temp, "Nhiệt độ", textColor)
        ControlRow(Icons.Default.Lightbulb, "Đèn trần", den == 1, textColor, cardColor) { db.child("PhongKhach/Den").setValue(if(it) 1 else 0) }
        ControlRow(Icons.Default.AcUnit, "Điều hòa", ac == 1, textColor, cardColor) { db.child("PhongKhach/DieuHoa").setValue(if(it) 1 else 0) }
        Text("Độ ẩm hiện tại: $humi%", color = ThoOrangePrimary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 15.dp))
    }
}

@Composable
fun KitchenScreen(navController: NavHostController, db: DatabaseReference, gas: Int, coLua: Int, den: Int, quat: Int, textColor: Color, cardColor: Color) {
    Column(modifier = Modifier.padding(20.dp)) {
        Header(navController, "NHÀ BẾP", textColor)
        GaugeLight(gas.toDouble(), "Khí Gas", textColor, 1000.0)
        Text(if(coLua == 1) "⚠️ CẢNH BÁO: CÓ LỬA!" else if (gas > 400) "⚠️ NGUY HIỂM: Rò rỉ khí Gas!" else "✅ Bếp an toàn", color = if(coLua==1 || gas > 400) HoaRed else ThoOrangePrimary, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth().padding(vertical=15.dp), textAlign = TextAlign.Center, fontSize = 18.sp)
        ControlRow(Icons.Default.Air, "Quạt hút", quat == 1, textColor, cardColor) { db.child("NhaBep/QuatHut").setValue(if(it) 1 else 0) }
        ControlRow(Icons.Default.Lightbulb, "Đèn bếp", den == 1, textColor, cardColor) { db.child("NhaBep/Den").setValue(if(it) 1 else 0) }
    }
}

@Composable
fun BedroomScreen(navController: NavHostController, db: DatabaseReference, den: Int, quat: Int, tDen: String, tQuat: String, textColor: Color, cardColor: Color) {
    val context = LocalContext.current
    fun showPicker(onTime: (String) -> Unit) {

        val cal = Calendar.getInstance()
        TimePickerDialog(context, { _, h, m -> onTime(String.format("%02d:%02d", h, m)) }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
    }
    Column(modifier = Modifier.padding(20.dp)) {
        Header(navController, "PHÒNG NGỦ", textColor)
        WhiteCard(cardColor) {
            Column(modifier = Modifier.padding(15.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {

                    Icon(Icons.Default.Lightbulb, null, tint = if(den==1) MyOrange else Color.Gray)
                    Text(" Đèn phòng ngủ", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, color = textColor)
                    Switch(checked = den == 1, onCheckedChange = { db.child("PhongNgu/Den").setValue(if(it) 1 else 0) }, colors = SwitchDefaults.colors(checkedThumbColor = ThoOrangePrimary, checkedTrackColor = ThoBeige))

                }
                Divider(modifier = Modifier.padding(vertical = 10.dp), thickness = 0.5.dp)
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { showPicker { db.child("PhongNgu/TimerDen").setValue(it) } }) {
                    Icon(Icons.Default.Timer, null, tint = Color.Gray, modifier = Modifier.size(20.dp))

                    Text(" Hẹn giờ tắt: ", fontSize = 14.sp, color = textColor)
                    Text(tDen, fontWeight = FontWeight.Bold, color = ThoBrownPrimary)
                    Spacer(modifier = Modifier.weight(1f))
                    if(tDen != "Chưa đặt") Text("Xóa", color = HoaRed, fontSize = 12.sp, modifier = Modifier.clickable {
                        db.child("PhongNgu/TimerDen").setValue("Chưa đặt") })
                }
            }
        }
        Spacer(modifier = Modifier.height(15.dp))
        WhiteCard(cardColor) {
            Column(modifier = Modifier.padding(15.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {

                    Icon(Icons.Default.Air, null, tint = if(quat==1) ThoBrownPrimary else Color.Gray)
                    Text(" Quạt giường", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, color = textColor)
                    Switch(checked = quat == 1, onCheckedChange = { db.child("PhongNgu/Quat").setValue(if(it) 1 else 0) }, colors = SwitchDefaults.colors(checkedThumbColor = ThoOrangePrimary, checkedTrackColor = ThoBeige))

                }
                Divider(modifier = Modifier.padding(vertical = 10.dp), thickness = 0.5.dp)
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { showPicker { db.child("PhongNgu/TimerQuat").setValue(it) } }) {
                    Icon(Icons.Default.Timer, null, tint = Color.Gray, modifier = Modifier.size(20.dp))

                    Text(" Hẹn giờ tắt: ", fontSize = 14.sp, color = textColor)
                    Text(tQuat, fontWeight = FontWeight.Bold, color = ThoBrownPrimary)
                    Spacer(modifier = Modifier.weight(1f))
                    if(tQuat != "Chưa đặt") Text("Xóa", color = HoaRed, fontSize = 12.sp, modifier = Modifier.clickable { db.child("PhongNgu/TimerQuat").setValue("Chưa đặt") })

                }
            }
        }
    }
}

@Composable
fun BalconyScreen(navController: NavHostController, db: DatabaseReference, rain: Boolean, phoi: Int, auto: Int, startTime: Long, textColor: Color, cardColor: Color) {
    var timerText by remember { mutableStateOf("0 phút") }
    LaunchedEffect(phoi, startTime) {
        while (phoi == 1 && startTime > 0) {

            val diff = System.currentTimeMillis() - startTime
            timerText = "${(diff / 3600000)}h ${(diff / 60000) % 60}p"
            delay(60000)
        }
    }
    LazyColumn(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        item {
            Header(navController, "BAN CÔNG", textColor)

            Icon(if(rain) Icons.Default.WaterDrop else Icons.Default.WbSunny, null, modifier = Modifier.size(100.dp), tint = if(rain) Color.Blue else MyOrange)
            Text(if(rain) "TRỜI ĐANG MƯA" else "TRỜI NẮNG RÁO", fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.padding(10.dp), color = textColor)
            Spacer(modifier = Modifier.height(10.dp))

            WhiteCard(cardColor) {
                Row(modifier = Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoMode, null, tint = if(auto==1) ThoOrangePrimary else Color.Gray)
                    Column(modifier = Modifier.weight(1f).padding(start=10.dp)) {
                        Text("Phơi đồ tự động", fontWeight = FontWeight.Bold, color = textColor)
                        Text("Tự đem ra khi nắng, cất khi mưa", fontSize = 12.sp, color = Color.Gray)
                    }

                    Switch(checked = auto == 1, onCheckedChange = { db.child("BanCong/AutoMode").setValue(if(it) 1 else 0) }, colors = SwitchDefaults.colors(checkedThumbColor = ThoOrangePrimary, checkedTrackColor = ThoBeige))
                }
            }
            Spacer(modifier = Modifier.height(15.dp))
            WhiteCard(cardColor) {

                Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (phoi == 1) { Text("👕 ĐANG PHƠI ĐỒ", color = ThoOrangePrimary, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        Text("Đã phơi được: $timerText", color = Color.Gray, modifier = Modifier.padding(top=5.dp)) }
                    else { Text("📦 ĐÃ GOM ĐỒ VÀO", color = Color.Gray, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp) }
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(15.dp)) {

                        Button(onClick = { db.child("BanCong/GiaPhoi").setValue(1); db.child("BanCong/StartTime").setValue(System.currentTimeMillis()) }, colors = ButtonDefaults.buttonColors(containerColor = if(phoi==1) ThoOrangePrimary else Color.LightGray), modifier = Modifier.weight(1f)) { Text("ĐẨY RA") }
                        Button(onClick = { db.child("BanCong/GiaPhoi").setValue(0) }, colors = ButtonDefaults.buttonColors(containerColor = if(phoi==0) ThoBrownPrimary else Color.LightGray), modifier = Modifier.weight(1f)) { Text("GOM VÀO") }
                    }

                }
            }
        }
    }
}

// ================= CÁC COMPONENT TIỆN ÍCH =================
@Composable
fun ScenarioButton(title: String, icon: ImageVector, color: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier.height(80.dp), colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.15f)), shape = RoundedCornerShape(12.dp)) {
        Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {

            Icon(icon, null, tint = color)
            Text(title, color = color, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top=8.dp))
        }
    }
}

@Composable
fun Header(navController: NavHostController, title: String, textColor: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp)) {
        IconButton(onClick = { navController.popBackStack() }) { Icon(Icons.Default.ArrowBack, null, tint = textColor) }
        Text(title, fontWeight = FontWeight.Black, fontSize = 20.sp, color = textColor)
    }
}

@Composable
fun RoomCard(title: String, status: String, icon: ImageVector, color: Color, cardColor: Color, textColor: Color, isEnabled: Boolean = true, onClick: () -> Unit) {
    Card(
        onClick = { if (isEnabled) onClick() },
        modifier = Modifier.height(130.dp).alpha(if(isEnabled) 1f else 0.4f),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(15.dp).fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, null, tint = if(isEnabled) color else Color.Gray, modifier = Modifier.size(35.dp))
            Column { Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = if(isEnabled) textColor else Color.Gray)
                Text(status, color = Color.Gray, fontSize = 12.sp) }
        }
    }
}

@Composable
fun ControlRow(icon: ImageVector, title: String, isChecked: Boolean, textColor: Color, cardColor: Color, onCheckedChange: (Boolean) -> Unit) {
    WhiteCard(cardColor, modifier = Modifier.padding(top = 10.dp)) {
        Row(modifier = Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = if(isChecked) ThoBrownPrimary else Color.Gray)
            Text(" $title", modifier = Modifier.weight(1f), color = textColor)

            Switch(checked = isChecked, onCheckedChange = onCheckedChange, colors = SwitchDefaults.colors(checkedThumbColor = ThoOrangePrimary, checkedTrackColor = ThoBeige))
        }
    }
}

@Composable
fun WhiteCard(cardColor: Color, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Card(modifier = modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = cardColor), shape = RoundedCornerShape(15.dp), elevation = CardDefaults.cardElevation(2.dp)) { content() }
}

@Composable
fun GaugeLight(value: Double, label: String, textColor: Color, max: Double = 50.0) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxWidth().height(180.dp)) {
        val sweep by animateFloatAsState((value.toFloat() / max.toFloat() * 240f).coerceAtMost(240f), tween(1000))
        Canvas(Modifier.size(150.dp)) {
            drawArc(Color.LightGray.copy(0.3f), 150f, 240f, false, style = Stroke(15.dp.toPx(), cap = StrokeCap.Round))
            drawArc(if(value > max*0.8) HoaRed else ThoOrangePrimary, 150f, sweep, false, style = Stroke(15.dp.toPx(), cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${value.toInt()}", fontSize = 32.sp, fontWeight = FontWeight.Black, color = textColor)

            Text(label, fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
fun LineChartNative(data: List<Float>) {
    if (data.isEmpty()) return
    val maxVal = (data.maxOrNull() ?: 40f) + 2f
    val minVal = (data.minOrNull() ?: 20f) - 2f
    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height
        val pointSpacing = width / (data.size.coerceAtLeast(2) - 1)
        val path = Path()
        data.forEachIndexed { index, value ->
            val x = index * pointSpacing
            val y = height - ((value - minVal) / (maxVal - minVal) * height)
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)

            drawCircle(color = HoaRed, radius = 6f, center = Offset(x, y)) // Chấm đỏ tương sinh
        }
        drawPath(path = path, color = ThoOrangePrimary, style = Stroke(width = 4f, cap = StrokeCap.Round, join = StrokeJoin.Round)) // Đường line Cam Đất
    }
}